package com.codelib.android

import android.content.ContentValues
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import com.codelib.android.databinding.ActivityMainBinding
import com.itextpdf.text.Document
import com.itextpdf.text.Font
import com.itextpdf.text.Paragraph
import com.itextpdf.text.pdf.PdfWriter

class MainActivity : AppCompatActivity() {

    private lateinit var dataBinding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        dataBinding = DataBindingUtil.setContentView(this, R.layout.activity_main)

        dataBinding.btnCreatePDF.setOnClickListener {
            val values = ContentValues()
            values.put(MediaStore.MediaColumns.DISPLAY_NAME,"YourFileName")
            values.put(MediaStore.MediaColumns.MIME_TYPE,"application/pdf")
            // If you you want to create folder just add String means folder name like this
            //values.put(MediaStore.MediaColumns.RELATIVE_PATH,Environment.DIRECTORY_DOCUMENTS + "/FolderName" )
            values.put(MediaStore.MediaColumns.RELATIVE_PATH,Environment.DIRECTORY_DOCUMENTS)
            val uri: Uri? = contentResolver.insert(MediaStore.Files.getContentUri("external"),values)

            if (uri != null) {
                val outputStream = contentResolver.openOutputStream(uri)
                val document = Document()
                PdfWriter.getInstance(document,outputStream)
                document.open()
                document.addAuthor("CodeLib")
                addDataIntoPDF(document)
                document.close()
                Toast.makeText(this,"PDF Created",Toast.LENGTH_LONG)
            }
        }
    }

    fun addDataIntoPDF(document: Document) {
        val paraGraph = Paragraph()
        val headingFont = Font(Font.FontFamily.HELVETICA,24F,Font.BOLD)
        paraGraph.add(Paragraph("CodeLib PDF",headingFont))
        addEmptyLines(paraGraph,1)
        paraGraph.add(Paragraph("Youtube123455"))
        addEmptyLines(paraGraph,1)
        paraGraph.add(Paragraph("Video"))
        document.add(paraGraph)
    }

    fun addEmptyLines(paragraph: Paragraph,lineCount:Int){
        for (i in 0 until lineCount) {
            paragraph.add(Paragraph(""))
        }
    }
}
